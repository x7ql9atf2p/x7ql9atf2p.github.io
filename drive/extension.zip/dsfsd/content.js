(function () {
    let removeAttempts = 0;
    // Function to remove all canvas elements
    function removeCanvases() {
        const canvasElements = document.querySelectorAll("canvas"); // fetch all canvas elements.
        if (canvasElements.length === 0) {
            return; // exit if no canvas elements are found
        }
        canvasElements.forEach(canvas => {
            canvas.remove(); // remove all canvas elements.
        });
        removeAttempts++;
        if (removeAttempts >= 10) {
            chrome.runtime.sendMessage({action: "forceClose"}); // if canvases keep being created after 10 attempts, close the tab.
        }
    }
	
	setInterval(removeCanvases, 1)
})();